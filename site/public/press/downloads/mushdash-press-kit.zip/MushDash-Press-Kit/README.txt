﻿MushDash Press Kit
==================

These assets are provided for editorial and media coverage of MushDash.

Official Game Name: MushDash
Developer: Lv.B
Official Website: https://lvb.kr/
Game Page: https://lvb.kr/games/mushdash/
Press Contact: lvb909@naver.com

Included Files:
- Key-Art/ — official key art
- Logo/ — official transparent game logo
- Press-Image/ — official wide press image
- Promotional-Images/ — official promotional images
- FACT_SHEET_EN.txt — English fact sheet
- FACT_SHEET_KO.txt — Korean fact sheet
- FACT_SHEET_JA.txt — Japanese fact sheet
- FACT_SHEET_ZH-CN.txt — Simplified Chinese fact sheet

Use the supplied logo and images only in connection with MushDash or Lv.B coverage. Keep artwork proportions unchanged and do not present edited material as official artwork.
