﻿MushHero Press Kit
==================

These assets are provided for editorial and media coverage of MushHero.

Official Game Name: MushHero
Developer: Lv.B
Official Website: https://lvb.kr/
Game Page: https://lvb.kr/games/mushhero/
Press Contact: lvb909@naver.com

Included Files:
- Key-Art/ — official key art
- Logo/ — official transparent game logo
- Press-Image/ — official wide press image
- Screenshots/ — official gameplay screenshots
- FACT_SHEET_EN.txt — English fact sheet
- FACT_SHEET_KO.txt — Korean fact sheet
- FACT_SHEET_JA.txt — Japanese fact sheet
- FACT_SHEET_ZH-CN.txt — Simplified Chinese fact sheet

Use the supplied logo and images only in connection with MushHero or Lv.B coverage. Keep artwork proportions unchanged and do not present edited material as official artwork.
