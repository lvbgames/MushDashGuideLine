﻿Lv.B Brand Assets
=================

These assets are provided for editorial and media coverage of Lv.B and its games.

Official Studio Name: Lv.B
Website: https://lvb.kr/
Press Contact: lvb909@naver.com
Official Game Names: MushHero, MushDash

Included Assets:
- Logo/lvb-logo-horizontal-transparent.png — transparent horizontal logo
- Logo/lvb-logo-stacked-transparent.png — transparent stacked logo
- Symbol/lvb-symbol-transparent.png — transparent Lv.B symbol
- Preview/lvb-brand-card-yellow.png — brand card preview
- Preview/lvb-brand-press-preview.png — press presentation preview
- BRAND_GUIDE.txt — concise name, color and logo-use guidance

Use the assets in connection with Lv.B, MushHero or MushDash coverage. Keep logo proportions unchanged and choose a background with sufficient contrast.
